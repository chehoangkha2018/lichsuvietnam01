# Hồn Việt — Cổ tích & Danh tướng

Trang web tĩnh (HTML/CSS/JS thuần, không cần framework hay build tool) giới thiệu các truyện cổ tích Việt Nam và những vị danh tướng trong lịch sử dân tộc. Nền chủ đạo màu đỏ – vàng lấy cảm hứng từ quốc kỳ Việt Nam, có hiệu ứng chữ 3D "khắc nổi" ẩn/hiện ở phần đầu trang, thẻ nội dung nghiêng 3D theo con trỏ chuột, và dòng thời gian các danh tướng.

## Cấu trúc thư mục

```
vn-legends/
├── index.html        # Toàn bộ cấu trúc trang
├── css/
│   └── style.css      # Design token + toàn bộ style
├── js/
│   └── script.js       # Dữ liệu nội dung + tương tác (dialog, 3D tilt, menu)
└── README.md
```

## Cách chạy trên máy (VS Code)

1. Mở thư mục `vn-legends` bằng VS Code.
2. Cài extension **Live Server** (nếu chưa có).
3. Click chuột phải vào `index.html` → **Open with Live Server**.
   - Hoặc chạy nhanh bằng terminal: `npx serve .` rồi mở link được in ra.

> Không nên mở trực tiếp `index.html` bằng cách double-click (giao thức `file://`) vì một số trình duyệt sẽ chặn font — hãy dùng một local server nhỏ như trên.

## Đưa lên GitHub

```bash
cd vn-legends
git init
git add .
git commit -m "Khởi tạo trang Hồn Việt"
git branch -M main
git remote add origin <URL-repo-của-bạn>.git
git push -u origin main
```

### Xuất bản miễn phí bằng GitHub Pages

1. Vào **Settings → Pages** trong repo trên GitHub.
2. Ở mục **Source**, chọn nhánh `main` và thư mục `/root`.
3. Lưu lại — sau ít phút trang sẽ có tại `https://<tên-tài-khoản>.github.io/<tên-repo>/`.

## Thêm nội dung mới

Toàn bộ nội dung (truyện cổ tích, danh tướng) nằm trong hai mảng `TALES` và `GENERALS` ở đầu file `js/script.js`. Chỉ cần thêm một object mới vào mảng tương ứng, trang sẽ tự render thêm thẻ/mốc thời gian mà không cần sửa HTML hay CSS.

## Công nghệ sử dụng

- HTML5 ngữ nghĩa, CSS3 thuần (custom properties, grid, animation) — không phụ thuộc framework.
- JavaScript thuần (vanilla), không thư viện ngoài.
- Font chữ: [Playfair Display](https://fonts.google.com/specimen/Playfair+Display) (tiêu đề) và [Be Vietnam Pro](https://fonts.google.com/specimen/Be+Vietnam+Pro) (nội dung) từ Google Fonts.
- Tôn trọng `prefers-reduced-motion` và có trạng thái focus rõ ràng cho điều hướng bàn phím.
